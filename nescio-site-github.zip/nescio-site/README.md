# NESCIO — site

Site pessoal de NESCIO, em HTML/CSS/JS puro (sem build, sem dependências de npm).

## Estrutura

```
.
├── index.html        → estrutura e conteúdo da página
├── css/
│   └── style.css     → todo o design (tokens de cor, tipografia, layout)
├── js/
│   └── main.js       → nav ao scroll, menu mobile, "tape counter" e reveal on scroll
└── README.md
```

## Ver localmente

Basta abrir o `index.html` diretamente no browser (duplo clique), ou correr um servidor simples a partir desta pasta:

```bash
python3 -m http.server 8000
```

e abrir `http://localhost:8000`.

## Publicar no GitHub Pages

1. Cria um repositório novo no GitHub (ex.: `nescio-site`).
2. Faz upload destes ficheiros para a raiz do repositório (mantendo as pastas `css/` e `js/`), ou:
   ```bash
   git init
   git add .
   git commit -m "primeira versão do site"
   git branch -M main
   git remote add origin https://github.com/<o-teu-user>/nescio-site.git
   git push -u origin main
   ```
3. No GitHub, vai a **Settings → Pages**.
4. Em "Branch", escolhe `main` e a pasta `/ (root)`, depois **Save**.
5. Ao fim de um ou dois minutos, o site fica disponível em:
   `https://<o-teu-user>.github.io/nescio-site/`

Se quiseres um domínio próprio (ex. `nescio.pt`), adiciona um ficheiro `CNAME` na raiz do repositório com esse domínio, e aponta o DNS do domínio para o GitHub Pages.

## Nota sobre as imagens

As imagens usadas em "Cicatrizes do Comum" e no interlúdio ainda apontam para o CDN do Wix (`static.wixstatic.com`). Isso funciona, mas fica dependente do Wix continuar a servir esses ficheiros. Para uma versão totalmente independente:

1. Descarrega as imagens.
2. Coloca-as numa pasta `assets/img/`.
3. Substitui os `src="https://static.wixstatic.com/..."` no `index.html` pelos caminhos locais (ex. `assets/img/caes-enraivecidos.jpg`).

## Nota sobre as fontes

As fontes (Fraunces, Newsreader, IBM Plex Mono) carregam da Google Fonts via `<link>` no `<head>` do `index.html` — não precisam de nenhum ficheiro extra no repositório.
